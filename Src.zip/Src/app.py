import GR.principal as gr

# cliente, user = juan_yavi@gmail.com  ; contraseña = hPmimkTo
# personal, user = juan_torrico@gmail.com ; contraseña = UIYgSsmO



raiz = gr.Raiz()    
raiz.frame_principal()  	                                                                                                                                                                                                                                                                    
raiz.mostrar()

if gr.Estado == "cliente":
    datos = gr.Informacion
    raiz_fija = gr.Cliente(datos)
    raiz_fija.frame_principal()
    raiz_fija.mostrar()
    
if gr.Estado == "personal":
    datos = gr.Informacion
    raiz_fija = gr.Personal(datos)
    raiz_fija.frame_principal()
    raiz_fija.mostrar()
    
if gr.Estado == "administrator":
    datos = gr.Informacion
    raiz = gr.Administrator(datos)
    raiz_fija.frame_principal()
    raiz_fija.mostrar()
