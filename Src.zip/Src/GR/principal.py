import customtkinter as ctk
import os
from PIL import Image
from . import coneccion as cone
import tkinter as tk

#----- DIRECTORIOS
carpeta_principal = os.path.dirname(__file__)
carpeta_imagenes = os.path.join(carpeta_principal, "Imagenes")
#----- IMAGENES
admin = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "admin.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "admin.png"))), 
        size=(50, 50))
admin_login = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "admin_login.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "admin_login.png"))), 
        size=(50, 50))
black_friday = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "black_friday.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "black_friday.png"))), 
        size=(50, 50))
catalogo = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "catalogo.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "catalogo.png"))), 
        size=(50, 50))
cliente = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "cliente.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "cliente.png"))), 
        size=(350, 250))
cliente_login = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "cliente_login.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "cliente_login.png"))), 
        size=(50, 50))
empleado = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "empleado.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "empleado.png"))), 
        size=(50, 50))
personal_login = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "personal_login.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "personal_login.png"))), 
        size=(50, 50))
enviar = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "enviar.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "enviar.png"))), 
        size=(25, 25)) # Tamaño de las imágenes
logo = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "logo.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "logo.png"))), 
        size=(250, 250)) # Tamaño de las imágenes
registro = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "registro.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "registro.png"))), 
        size=(50, 50))
salir = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "salir.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "salir.png"))), 
        size=(50, 50))
usuario = ctk.CTkImage(
        light_image=Image.open((os.path.join(carpeta_imagenes, "usuario.png"))),
        dark_image=Image.open((os.path.join(carpeta_imagenes, "usuario.png"))), 
        size=(50, 50))
#----- COLORES
c_negro = "#010101"
c_blanco = "#FFFFFF"
c_morado = "#56008c"
c_verde_claro = "#AFF997"
c_cian = "#3199BE"

#Informacion Global
Estado = None
Informacion = None


# CLASE PRINCIPAL

class Raiz:
        def __init__(self):
                self.vent_sec_est = False
                self.accion = False
                self.ventana = ctk.CTk()
                self.ventana.config(bg=c_negro)
                self.ventana.geometry("500x600+350+20")
                self.ventana.minsize(500, 600)
                self.ventana.title("TIENDA ELIZABETH")
                self.ventana.iconbitmap(os.path.join(carpeta_imagenes, "logo.ico"))
                self.ventana.columnconfigure(0, weight=1)
                self.ventana.rowconfigure(0, weight=1)
                 
        def cerrar_ventana_secundaria(self):
                self.vent_sec_est = False
        def cerrar_mensaje(self):
                self.accion = False
        def mostrar(self):
                self.ventana.mainloop()       
        def salir_todo(self):
                self.ventana.destroy()   
        def crear_cliente(self, origen:object,nickname:str, nombre:str, apellido:str, carnet:str, nacimiento:str,
                        correo:str, password:str, password_2:str,listo:bool):
                if not self.accion:
                        if nickname=="" or nombre == "" or apellido == "" or carnet == "" or nacimiento =="" or correo == "" or password == "" or password_2 == "":
                                mensaje = ctk.CTkToplevel(origen)
                                mensaje.title("ERROR")
                                mensaje.geometry("500x50+1050+850")
                                mensaje.resizable(False, False)
                                ctk.CTkLabel(mensaje, text="Uno de los datos esta VACIO").pack(padx = 10, pady = 10)
                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                self.accion = True       
                        else:
                                if listo:
                                        if password == password_2:
                                                datos: list = [nickname,nombre,apellido,carnet,nacimiento,correo,password]
                                                conexion = cone.BaseDato()
                                                result = conexion.crear_cliente(datos)
                                                mensaje = ctk.CTkToplevel(origen)
                                                mensaje.title("Registrar Cliente")
                                                mensaje.geometry("500x50+1050+850")
                                                mensaje.resizable(False, False)
                                                ctk.CTkLabel(mensaje, text=result).pack(padx = 10, pady = 10)
                                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                                self.accion = True
                                        else:
                                                mensaje = ctk.CTkToplevel(origen)
                                                mensaje.title("ERROR")
                                                mensaje.geometry("500x50+1050+850")
                                                mensaje.resizable(False, False)
                                                ctk.CTkLabel(mensaje, text="Contraseñás DIFERENTES. \n No se pudo crear su USUARIO").pack(padx = 10, pady = 10)
                                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                                self.accion = True
                                else:
                                        mensaje = ctk.CTkToplevel(origen)
                                        mensaje.title("ERROR")
                                        mensaje.geometry("500x50+1050+850")
                                        mensaje.resizable(False, False)
                                        ctk.CTkLabel(mensaje, text="Falta Tickear el CheckBox.").pack(padx = 10, pady = 10)
                                        mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                        self.accion = True
        def crear_frame_fijo(self, datos:tuple, type:str):
                global Estado, Informacion
                Estado = type
                Informacion = datos
                self.ventana.destroy()
        def logear_admin(self,origen:object,correo:str, password:str):
                if correo == "" or password == "" :
                        mensaje = ctk.CTkToplevel(origen)
                        mensaje.title("ERROR")
                        mensaje.geometry("500x50+1050+850")
                        mensaje.resizable(False, False)
                        ctk.CTkLabel(mensaje, text="Uno de los datos esta VACIO").pack(padx = 10, pady = 10)
                        mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                        self.accion = True 
                else:
                        if correo != "admin@gmail.com" or correo != "123456":
                                mensaje = ctk.CTkToplevel(origen)
                                mensaje.title("ERROR")
                                mensaje.geometry("500x50+1050+850")
                                mensaje.resizable(False, False)
                                ctk.CTkLabel(mensaje, text="Uno de los datos esta VACIO").pack(padx = 10, pady = 10)
                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                self.accion = True
                        else:
                                self.crear_frame_fijo((correo,password), "administrador")
                                 
        def logear_usuario(self,origen:object,correo:str, password:str, check_personal:bool):
                if not self.accion:
                        if correo == "" or password == "" :
                                mensaje = ctk.CTkToplevel(origen)
                                mensaje.title("ERROR")
                                mensaje.geometry("500x50+1050+850")
                                mensaje.resizable(False, False)
                                ctk.CTkLabel(mensaje, text="Uno de los datos esta VACIO").pack(padx = 10, pady = 10)
                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                self.accion = True       
                        else:
                                if check_personal:
                                        datos = ["PERSONAL",correo,password]
                                        conexion = cone.BaseDato()
                                        result = conexion.login_user(datos)
                                        if result == []:
                                                mensaje = ctk.CTkToplevel(origen)
                                                mensaje.title("ERROR")
                                                mensaje.geometry("500x50+1050+850")
                                                mensaje.resizable(False, False)
                                                ctk.CTkLabel(mensaje, text="Error, PERSONAL NO EXISTE").pack(padx = 10, pady = 10)
                                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                                self.accion = True
                                        else:
                                                self.crear_frame_fijo(result, "personal")
                                else:
                                        datos = ["CLIENTE",correo,password]
                                        conexion = cone.BaseDato()
                                        result = conexion.login_user(datos)
                                        if result == []:
                                                mensaje = ctk.CTkToplevel(origen)
                                                mensaje.title("ERROR")
                                                mensaje.geometry("500x50+1050+850")
                                                mensaje.resizable(False, False)
                                                ctk.CTkLabel(mensaje, text="Error, CLIENTE NO EXISTE").pack(padx = 10, pady = 10)
                                                mensaje.bind("<Destroy>", lambda _:self.cerrar_mensaje())
                                                self.accion = True
                                        else:
                                                self.crear_frame_fijo(result, "cliente")
        
        def frame_principal(self):
                #diccionario con los botones y sus atributos (imagen, funcion, fila, columna)
                botons:dict = {
                        "Iniciar Sesion": [usuario, lambda: self.abrir_ventana(1), 2, 0],
                        "Registrarse": [registro,lambda: self.abrir_ventana(2),2, 1],
                        "Catalogo": [catalogo,lambda: self.abrir_ventana(3), 3, 0],
                        "Solicitud":[empleado,lambda: self.abrir_ventana(4), 3, 1],
                        "Administrador":[admin,lambda: self.abrir_ventana(5), 4, 0],
                        "Salir":[salir, lambda: self.abrir_ventana(6), 4, 1]
                }
                # VENTA PRINCIPAL AL ABRIR LA APLICACION
                        #definir el frame_principal:
                self.frame = ctk.CTkFrame(self.ventana, fg_color= c_negro, corner_radius=0)
                self.frame.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                self.frame.columnconfigure([0,1], weight=1)
                self.frame.rowconfigure([0,1,2,3,4,5], weight=1)
                #insertar el logo dentro del frame_principal:
                ctk.CTkLabel(master=self.frame,
                               image=logo,
                               text="").grid(columnspan = 2, rowspan=2, padx = 15, pady = 15)
                #insertar botones dentro del frame_principal:
                for boton in botons:
                        ctk.CTkButton(self.frame, image=botons[boton][0], text=boton,text_color=c_blanco,
                                        hover_color= c_morado,fg_color=c_negro, border_color=c_verde_claro,
                                        corner_radius=12, border_width=3,command=botons[boton][1]).grid(column = botons[boton][3],
                                        row=botons[boton][2], pady = 10)
                                
        def abrir_ventana(self, num_bot: int):
                if not self.vent_sec_est:
                        #Boton Iniciar Sesion : complete
                        if num_bot == 1:
                                self.ventana_secundaria1 = ctk.CTkToplevel(self.ventana)
                                self.ventana_secundaria1.config(bg=c_negro)
                                self.ventana_secundaria1.geometry("500x600+1050+20")
                                self.ventana_secundaria1.minsize(500, 600)
                                self.ventana_secundaria1.title("LOGIN")
                                self.ventana_secundaria1.columnconfigure(0, weight=1)
                                self.ventana_secundaria1.rowconfigure(0, weight=1)
                                
                                frame1 = ctk.CTkFrame(self.ventana_secundaria1, fg_color= c_negro, corner_radius=0)
                                frame1.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                                frame1.columnconfigure([0,1], weight=1)
                                frame1.rowconfigure([0,1,2,3,4,5], weight=1)
                                #insertar el logo dentro del frame_principal:
                                ctk.CTkLabel(master=frame1,
                                        image=cliente,
                                        text="").grid(columnspan = 2, row=0, padx = 15, pady = 15)
                                #insertar Entry, Checkbooks, y boton dentro del frame:
                                correo = ctk.CTkEntry(frame1, placeholder_text="Correo electronico:",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                correo.grid(columnspan=2, row=1, pady=0)

                                password = ctk.CTkEntry(frame1, placeholder_text="Contraseña:",
                                border_color=c_verde_claro, fg_color=c_negro, show = "*",
                                width=100)
                                password.grid(columnspan=2, row=2, pady=0)

                                check_personal = ctk.CTkCheckBox(frame1, text="Soy un Personal de C.E.", border_width=2,
                                  fg_color=c_morado, hover_color=c_verde_claro)
                                check_personal.grid(columnspan=2, row=3, pady=0)
                        
                                ctk.CTkButton(frame1, image=enviar, text="ENVIAR",text_color=c_blanco,
                                hover_color= c_morado,fg_color=c_negro, border_color=c_verde_claro,
                                corner_radius=12, border_width=2, 
                                command= lambda: self.logear_usuario(frame1,correo.get(),
                                password.get(), check_personal.get())).grid(columnspan =2, row=4, pady=5)
                                
                                #Funcion para el cierre de la ventana secundaria
                                self.ventana_secundaria1.bind("<Destroy>", lambda _:self.cerrar_ventana_secundaria())
                                self.vent_sec_est = True
                        #Boton Registrar Usuario : complete       
                        if num_bot == 2:
                                self.ventana_secundaria1 = ctk.CTkToplevel(self.ventana)
                                self.ventana_secundaria1.config(bg=c_negro)
                                self.ventana_secundaria1.geometry("600x600+1050+20")
                                self.ventana_secundaria1.minsize(500, 600)
                                self.ventana_secundaria1.title("LOGIN")
                                self.ventana_secundaria1.columnconfigure(0, weight=1)
                                self.ventana_secundaria1.rowconfigure(0, weight=1)
                                
                                frame1 = ctk.CTkFrame(self.ventana_secundaria1, fg_color= c_negro, corner_radius=0)
                                frame1.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                                frame1.columnconfigure([0,1,3,4], weight=1)
                                frame1.rowconfigure([0,1,2,3,4,5,6,7,8], weight=1)
                                
                                #insertar el logo dentro del frame_principal:
                                ctk.CTkLabel(master=frame1,
                                        image=registro,
                                        text="").grid(column = 1,columnspan=3, row=0, padx = 15, pady = 15)
                                #insertar Entry, Checkbooks, y boton dentro del frame:
                                        #Nickname
                                ctk.CTkLabel(master=frame1,text="Nickname:").grid(column = 1, row = 1, sticky ="e",pady=5)
                                nickname = ctk.CTkEntry(frame1, placeholder_text="Ingresa tu nickname:",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                nickname.grid(column=2, row=1, sticky ="w",pady=5)
                                        #Nombre
                                ctk.CTkLabel(master=frame1,text="Nombre(s):").grid(column = 1, row = 2, sticky ="e",pady=5)
                                nombre = ctk.CTkEntry(frame1, placeholder_text="Ingresa tus Nombres:",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                nombre.grid(column=2, row=2, sticky ="w",pady=5)
                                        #apellido
                                ctk.CTkLabel(master=frame1,text="Apellido(s):").grid(column = 1, row = 3, sticky ="e",pady=5)
                                apellido = ctk.CTkEntry(frame1, placeholder_text="Ingresa tus Apellidos:",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                apellido.grid(column=2, row=3, sticky ="w",pady=5)
                                        #Carnet
                                ctk.CTkLabel(master=frame1,text="Carnet:").grid(column = 1, row = 4, sticky ="e",pady=5)
                                carnet = ctk.CTkEntry(frame1, placeholder_text="Ingresa tu Carnet de Identidad:",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                carnet.grid(column=2, row=4, sticky ="w",pady=5)
                                        #F_nacimiento
                                ctk.CTkLabel(master=frame1,text="Fecha Nacimiento:").grid(column = 1, row = 5, sticky ="e",pady=5)
                                nacimiento = ctk.CTkEntry(frame1, placeholder_text="Ingresalo (yyyy-mm-dd):",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                nacimiento.grid(column=2, row=5, sticky ="w",pady=5)
                                        #correo
                                ctk.CTkLabel(master=frame1,text="Correo:").grid(column = 1, row = 6, sticky ="e",pady=5)
                                correo = ctk.CTkEntry(frame1, placeholder_text="Ingresa tu correo (la extension final es automatica):",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                correo.grid(column=2, row=6, sticky ="we",pady=5)
                                ctk.CTkLabel(master=frame1,text="@gmail.com").grid(column = 3, row = 6, sticky ="w",pady=5)
                                        #contraseña
                                ctk.CTkLabel(master=frame1,text="Password:").grid(column = 1, row = 7, sticky ="e",pady=5)
                                password = ctk.CTkEntry(frame1, placeholder_text="Escribe una contraseña que recuerdes:",
                                border_color=c_verde_claro, fg_color=c_negro, show = "*",
                                width=300)
                                password.grid(column=2, row=7, sticky ="w",pady=5)
                                        #repetir
                                ctk.CTkLabel(master=frame1,text="Confirmar password:").grid(column = 1, row = 8, sticky ="e",pady=5)
                                password_2 = ctk.CTkEntry(frame1, placeholder_text="Vuelve a escribirla:",
                                border_color=c_verde_claro, fg_color=c_negro, show = "*",
                                width=300)
                                password_2.grid(column=2, row=8, sticky ="w",pady=5)
                                        #Check LISTO
                                check_listo = ctk.CTkCheckBox(frame1, text="Presiona Listo Para Enviar tu registro como CLIENTE.", border_width=2,
                                  fg_color=c_morado, hover_color=c_verde_claro)
                                check_listo.grid(column=1, columnspan=3,row=9, pady=5)
                                        #Boton Enviar
                                ctk.CTkButton(frame1, image=enviar, text="ENVIAR",text_color=c_blanco,
                                hover_color= c_morado,fg_color=c_negro, border_color=c_verde_claro,
                                corner_radius=12, border_width=2, 
                                command= lambda: self.crear_cliente(origen=frame1,nickname=nickname.get(),nombre=nombre.get(),apellido= apellido.get(),carnet= carnet.get(),
                                        nacimiento=nacimiento.get(),correo=correo.get(), password=password.get(),password_2=password_2.get(),listo=check_listo.get())).grid(column =1,columnspan=3, row=10, pady=5)
                                
                                #Funcion para el cierre de la ventana secundaria
                                self.ventana_secundaria1.bind("<Destroy>", lambda _:self.cerrar_ventana_secundaria())
                                self.vent_sec_est = True
                        #Boton Ver Catalogo   
                        if num_bot == 3:
                                self.ventana_secundaria1 = ctk.CTkToplevel(self.ventana)
                                self.ventana_secundaria1.config(bg=c_negro)
                                self.ventana_secundaria1.geometry("800x600+1050+20")
                                self.ventana_secundaria1.minsize(500, 600)
                                self.ventana_secundaria1.title("CATALOGO")
                                self.ventana_secundaria1.columnconfigure(0, weight=1)
                                self.ventana_secundaria1.rowconfigure(0, weight=1)
                                
                                frame1 = ctk.CTkFrame(self.ventana_secundaria1, fg_color= c_morado, corner_radius=0)
                                frame1.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                        
                                conexion = cone.BaseDato()
                                rows = conexion.ver_catalogo()
                                txt = "MARCA     COLOR     PRECIO     GENERO     MODELO     MATERIAL     TALLA     STOCK\n"
                                ctk.CTkLabel(master=frame1,text=txt, text_color=c_blanco).grid(column = 0, row =0, pady = 5, sticky = "wesn")
                                sframe = ctk.CTkScrollableFrame(frame1, height =250, width=425)
                                sframe.place(x = 25, y = 25)
                                for row in rows:
                                        txt = f"{row[0]}     {row[1]}     {row[2]}     {row[3]}     {row[4]}     {row[5]}     {row[6]}     {row[7]}\n"
                                        btn = ctk.CTkLabel(sframe, text= txt, width=200, height=20)
                                        btn.pack()  
                                #insertar el catalogo dentro del frame_principal:
                                
                                #Funcion para el cierre de la ventana secundaria
                                self.ventana_secundaria1.bind("<Destroy>", lambda _:self.cerrar_ventana_secundaria())
                                self.vent_sec_est = True
                        #Boton Solicitud de Empleo      
                        if num_bot == 4:
                                self.ventana_secundaria1 = ctk.CTkToplevel(self.ventana)
                                self.ventana_secundaria1.config(bg=c_negro)
                                self.ventana_secundaria1.geometry("500x600+1050+20")
                                self.ventana_secundaria1.minsize(500, 600)
                                self.ventana_secundaria1.title("LOGIN")
                                self.ventana_secundaria1.columnconfigure(0, weight=1)
                                self.ventana_secundaria1.rowconfigure(0, weight=1)
                                
                                frame1 = ctk.CTkFrame(self.ventana_secundaria1, fg_color= c_negro, corner_radius=0)
                                frame1.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                                frame1.columnconfigure([0,1], weight=1)
                                frame1.rowconfigure([0,1], weight=1)
                                #insertar el logo dentro del frame_principal:
                                ctk.CTkLabel(master=frame1,
                                        text="REGISTROS COMPLETOS").grid(columnspan = 2, row=0, padx = 15, pady = 15)
                                #insertar Entry, Checkbooks, y boton dentro del frame:
                                
                                self.ventana_secundaria1.bind("<Destroy>", lambda _:self.cerrar_ventana_secundaria())
                                self.vent_sec_est = True
                        #Boton Administrador        
                        if num_bot == 5:
                                self.ventana_secundaria1 = ctk.CTkToplevel(self.ventana)
                                self.ventana_secundaria1.config(bg=c_negro)
                                self.ventana_secundaria1.geometry("500x600+1050+20")
                                self.ventana_secundaria1.minsize(500, 600)
                                self.ventana_secundaria1.title("LOGIN")
                                self.ventana_secundaria1.columnconfigure(0, weight=1)
                                self.ventana_secundaria1.rowconfigure(0, weight=1)
                                
                                frame1 = ctk.CTkFrame(self.ventana_secundaria1, fg_color= c_negro, corner_radius=0)
                                frame1.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                                frame1.columnconfigure([0,1], weight=1)
                                frame1.rowconfigure([0,1,2,3,4,5], weight=1)
                                #insertar el logo dentro del frame_principal:
                                ctk.CTkLabel(master=frame1,
                                        image=admin,
                                        text="").grid(columnspan = 2, row=0, padx = 15, pady = 15)
                                #insertar Entry, Checkbooks, y boton dentro del frame:
                                correo = ctk.CTkEntry(frame1, placeholder_text="Correo electronico:",
                                border_color=c_verde_claro, fg_color=c_negro,
                                width=300)
                                correo.grid(columnspan=2, row=1, pady=0)

                                password = ctk.CTkEntry(frame1, placeholder_text="Contraseña:",
                                border_color=c_verde_claro, fg_color=c_negro, 
                                width=100)
                                password.grid(columnspan=2, row=2, pady=0)
                        
                                ctk.CTkButton(frame1, image=enviar, text="ENVIAR",text_color=c_blanco,
                                hover_color= c_morado,fg_color=c_negro, border_color=c_verde_claro,
                                corner_radius=12, border_width=2, 
                                command= lambda: self.logear_admin(frame1,correo.get(), password.get())).grid(columnspan =2, row=3, pady=5)
                                
                                #Funcion para el cierre de la ventana secundaria
                                self.ventana_secundaria1.bind("<Destroy>", lambda _:self.cerrar_ventana_secundaria())
                                self.vent_sec_est = True
                        #Boton Salir de TODO : complete    
                        if num_bot == 6:
                                self.salir_todo()
         
                        
class Personal:
        def __init__(self, datos: list):
                self.vent_sec_est = False
                self.dato = datos[0]
                self.f_nac = self.dato[4]
                self.ventana = ctk.CTk()
                self.ventana.config(bg=c_negro)
                self.ventana.geometry("500x600+350+20")
                self.ventana.minsize(500, 600)
                self.ventana.title("TIENDA ELIZABETH")
                self.ventana.iconbitmap(os.path.join(carpeta_imagenes, "logo.ico"))
                self.ventana.columnconfigure(0, weight=1)
                self.ventana.rowconfigure(0, weight=1)
        def mostrar(self):
                self.ventana.mainloop() 
        # CAMBIAR TODO
        def frame_principal(self):
                #diccionario con los botones y sus atributos (imagen, funcion, fila, columna)
                botons:dict = {
                        "Iniciar Sesion": [usuario, lambda: self.abrir_ventana(1), 2, 0],
                        "Registrarse": [registro,lambda: self.abrir_ventana(2),2, 1],
                        "Catalogo": [catalogo,lambda: self.abrir_ventana(3), 3, 0],
                        "Solicitud":[empleado,lambda: self.abrir_ventana(4), 3, 1],
                        "Administrador":[admin,lambda: self.abrir_ventana(5), 4, 0],
                        "Cerrar Sesion":[salir, lambda: self.abrir_ventana(6), 4, 1]
                }
                # VENTA PRINCIPAL AL ABRIR LA APLICACION
                        #definir el frame_principal:
                self.frame = ctk.CTkFrame(self.ventana, fg_color= c_negro, corner_radius=0)
                self.frame.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                self.frame.columnconfigure([0,1], weight=1)
                self.frame.rowconfigure([0,1,2,3,4,5], weight=1)
                #insertar el logo dentro del frame_principal:
                ctk.CTkLabel(master=self.frame,
                               image=logo,
                               text="").grid(columnspan = 2, rowspan=2, padx = 15, pady = 15)
                #insertar botones dentro del frame_principal:
                for boton in botons:
                        ctk.CTkButton(self.frame, image=botons[boton][0], text=boton,text_color=c_blanco,
                                        hover_color= c_morado,fg_color=c_negro, border_color=c_verde_claro,
                                        corner_radius=12, border_width=3,command=botons[boton][1]).grid(column = botons[boton][3],
                                        row=botons[boton][2], pady = 10)
                
class Cliente:
        def __init__(self, datos: list):
                self.vent_sec_est = False
                self.dato = datos[0]
                self.f_nac = self.dato[4]
                self.ventana = ctk.CTk()
                self.ventana.config(bg=c_negro)
                self.ventana.geometry("500x600+350+20")
                self.ventana.minsize(500, 600)
                self.ventana.title("TIENDA ELIZABETH")
                self.ventana.iconbitmap(os.path.join(carpeta_imagenes, "logo.ico"))
                self.ventana.columnconfigure(0, weight=1)
                self.ventana.rowconfigure(0, weight=1)
        def mostrar(self):
                self.ventana.mainloop()
        
        def cerrar_ventana_secundaria(self):
                self.vent_sec_est = False
        
        def frame_principal(self):
                #diccionario con los botones y sus atributos (imagen, funcion, fila, columna)
                botons:dict = {
                        "Ver Catalogo": [ lambda: self.abrir_funcion(1), 1, 1],
                        "Historial Compras": [lambda: self.abrir_funcion(2),2, 1],
                        "Cambiar Correo": [lambda: self.abrir_funcion(3), 3, 1],
                        "Cambiar Contraseña":[lambda: self.abrir_funcion(4), 4, 1],
                        "Cerrar Sesion":[lambda: self.abrir_funcion(5), 5, 1]
                }
                # VENTA PRINCIPAL 
                        #definir el frame_principal:
                self.frame = ctk.CTkFrame(self.ventana, fg_color= c_negro, corner_radius=0)
                self.frame.grid(column=0, row=0, sticky="nsew", padx = 10, pady = 10)
                self.frame.columnconfigure([0,1], weight=1)
                self.frame.rowconfigure([0,1,2,3,4,5,6], weight=1)
                #insertar el logo dentro del frame_principal:
                ctk.CTkLabel(master=self.frame,image=cliente_login,text="").grid(column = 0,columnspan = 2, row=0, padx = 5, pady = 15)
                
                ctk.CTkLabel(master=self.frame,text=f"Numero Cliente: {self.dato[0]}").grid(column = 0, row=1, padx = 5, pady = 5)
                ctk.CTkLabel(master=self.frame,text=f"Nickname: {self.dato[1]}").grid(column = 0, row=2, padx = 5, pady = 5)
                ctk.CTkLabel(master=self.frame,text=f"Nombre: {self.dato[2]}").grid(column = 0, row=3, padx = 5, pady = 5)
                ctk.CTkLabel(master=self.frame,text=f"Apellido: {self.dato[3]}").grid(column = 0, row=4, padx = 5, pady = 5)
                ctk.CTkLabel(master=self.frame,text=f"Fecha Nacimiento: {self.f_nac.year} - {self.f_nac.month} - {self.f_nac.day}").grid(column = 0, row=5, padx = 5, pady = 15)
                ctk.CTkLabel(master=self.frame,text=f"Correo: {self.dato[5]}").grid(column = 0, row=6, padx = 5, pady = 5)
                
                for boton in botons:
                        ctk.CTkButton(self.frame, text=boton,text_color=c_blanco,
                                        hover_color= c_morado,fg_color=c_negro, border_color=c_verde_claro,
                                        corner_radius=12, border_width=3,command=botons[boton][0]).grid(column = botons[boton][2],
                                        row=botons[boton][1], pady = 5)
                
        def abrir_funcion(self,boton:int):
                if not self.vent_sec_est:
                        if boton == 1:
                                
                                ventana_secundaria1 = tk.Toplevel(self.ventana)
                                ventana_secundaria1.config(bg="black")
                                ventana_secundaria1.geometry("500x600+1050+20")
                                ventana_secundaria1.minsize(500, 600)
                                ventana_secundaria1.title("CATALOGO")
                                ventana_secundaria1.columnconfigure(0, weight=1)
                                ventana_secundaria1.rowconfigure(0, weight=1)

                                frame1 = tk.Frame(ventana_secundaria1, bg="purple")
                                frame1.grid(column=0, row=0, sticky="nsew", padx=10, pady=10)
                                frame1.columnconfigure([0, 1, 2, 3], weight=1)
                                frame1.rowconfigure([0, 1], weight=1)
                        
                                conexion = cone.BaseDato()
                                rows = conexion.ver_catalogo()
                                txt = "MARCA     COLOR     PRECIO     GENERO     MODELO     MATERIAL     TALLA     STOCK\n"
                                ctk.CTkLabel(master=frame1,text=txt, text_color=c_blanco).pack( pady = 5, sticky = "wesn")
                                sframe = ctk.CTkScrollableFrame(frame1, height =250, width=425)
                                sframe.pack()
                                for row in rows:
                                        txt = f"{row[0]}     {row[1]}     {row[2]}     {row[3]}     {row[4]}     {row[5]}     {row[6]}     {row[7]}\n"
                                        btn = ctk.CTkLabel(sframe, text= txt, width=200, height=20)
                                        btn.pack()  
                                
                                #Funcion para el cierre de la ventana secundaria
                                self.ventana_secundaria1.bind("<Destroy>", lambda _:self.cerrar_ventana_secundaria())
                                self.vent_sec_est = True
                                
                if boton == 2:
                        pass
                if boton == 3:
                        pass
                if boton == 4:
                        pass
                if boton == 5:
                        pass
                
class Administrador:
        def __init__(self, datos: list):
                self.datos = datos[0]
                self.ventana = ctk.CTk()
                self.ventana.config(bg=c_negro)
                self.ventana.geometry("500x600+350+20")
                self.ventana.minsize(500, 600)
                self.ventana.title("TIENDA ELIZABETH")
                self.ventana.iconbitmap(os.path.join(carpeta_imagenes, "logo.ico"))
                self.ventana.columnconfigure(0, weight=1)
                self.ventana.rowconfigure(0, weight=1)
        def mostrar(self):
                self.ventana.mainloop()            






                
                
