import cx_Oracle

class BaseDato:
    def __init__(self):
        self.conector = cx_Oracle.connect(
            user='SYSTEM',
            password='Ucb.8147071',
            dsn='localhost/xe',
            encoding='UTF-8'
        )
        self.cursor = self.conector.cursor()
        
    def consulta(self):
        cursor = self.cursor
        cursor.execute("""
                       SELECT * FROM HORARIO
                        """)
        rows = cursor.fetchall()
        for row in rows:
            print(row)
    
    def crear_cliente(self, datos: list):
    # Assuming datos: list = [nickname, nombre, apellido, carnet, nacimiento, correo, password]

        query = """
            INSERT INTO DATOS (ID, NOMBRE, APELLIDO, CI, FECHA_NAC, CORREO, CONTRASENA)
            VALUES (CLIENTE_SEC.NEXTVAL, :nombre, :apellido, :carnet, TO_DATE(:nacimiento, 'YYYY-MM-DD'), :correo, :password)
        """
        query2 = """
            SELECT D.ID FROM DATOS D WHERE D.CORREO = :correo
        """
        query3 = """
        INSERT INTO CLIENTE (ID, ID_DATOS, USUARIOS)
        VALUES (CLIENTE_SEC.NEXTVAL, :ID, :nickname)
        """

    # Construct parameters for the first query
        parametros = {
        'nombre': datos[1],
        'apellido': datos[2],
        'carnet': int(datos[3]),  # Convert to integer if necessary
        'nacimiento': datos[4],
        'correo': f"{datos[5]}@gmail.com",
        'password': datos[6]
        }

        try:
        # Execute the first query
            self.cursor.execute(query, parametros)
            self.conector.commit()

        # Execute the second query to get ID
            self.cursor.execute(query2, {'correo': parametros['correo']})
            id_datos = self.cursor.fetchone()[0]  # Fetch the first column of the first row

        # Execute the third query
            parametros_query3 = {'ID': id_datos, 'nickname': datos[0]}
            self.cursor.execute(query3, parametros_query3)
            self.conector.commit()

            return "Cliente creado exitosamente"
        except Exception as e:
            return f"Error al crear cliente: {str(e)}"

        
    def login_user(self, datos:list)->tuple:
        cursor = self.cursor
        if datos[0] == "CLIENTE":
            query = """
                SELECT C.ID, C.USUARIO, D.NOMBRE, D.APELLIDO, D.FECHA_NAC, D.CORREO, D.CONTRASENA 
                FROM CLIENTE C, DATOS D WHERE D.ID = C.ID_DATOS AND D.CORREO = :correo AND D.CONTRASENA = :password
            """
        if datos[0] == "PERSONAL":
            query = """
                SELECT C.ID, D.NOMBRE, D.APELLIDO, D.FECHA_NAC, C.NRO_CEL, C.DIRECCION, D.CORREO, D.CONTRASENA 
                FROM PERSONAL C, DATOS D WHERE D.ID = C.ID_DATOS AND D.CORREO = :correo AND D.CONTRASENA = :password
            """
        parametros = {
            'correo': datos[1],
            'password': datos[2],
        }
        try:
            cursor.execute(query, parametros)
            result = cursor.fetchall()
            return result
        except Exception as e:
            print(e)
            return []
        
    def ver_catalogo(self):
        cursor = self.cursor
        cursor.execute("""
                       SELECT P.MARCA, P.COLOR, P.PRECIO_UNIDAD, C.GENERO, C.ESTILO, C.MATERIAL, T.TALLA, S.CANTIDAD
                        FROM PRODUCTO P
                        JOIN CATEGORIA C ON P.ID_CATEGORIA = C.ID
                        JOIN STOCK S ON P.ID = S.ID_PRODUCTO
                        JOIN TALLAS T ON S.ID_TALLA = T.ID
                        """)
        rows = cursor.fetchall()
        return rows
    

    